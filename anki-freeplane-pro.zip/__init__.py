# Based on lajohnston/anki-freeplane (MIT), developed by aaa1386
from . import mindmap